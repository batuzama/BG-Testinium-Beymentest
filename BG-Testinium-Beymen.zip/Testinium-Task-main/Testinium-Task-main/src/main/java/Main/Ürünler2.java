package Main;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Ürünler2 extends BasePage {

    private static final Logger logger = LogManager.getLogger(BasePage.class);

    @Deprecated

    public Ürünler2(WebDriver driver) {

        super(driver);
    }

    public void productsPage2() throws InterruptedException {

        logger.info("Product page opened!");

        Thread.sleep(2000);

        scrollDownTwo();
        Thread.sleep(5000);

        //clickTo(By.id("moreContentButton"));
        Thread.sleep(5000);




        //randomSelect(By.xpath("//div[@class='m-productCard__photo']"));
        //logger.info("Product selected!");

        //Thread.sleep(2000);
    }
}