package Test;

import Main.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)

public class BeymenTest extends BaseTest {

    AnaSayfa anaSayfa;
    AramaKutusu aramaKutusu;
    Ürünler ürünler;
    ÜrünDetayı ürünDetayı;
    Sepetim sepetim;
    ÜrünSilme ürünSilme;
    Ürünler2 ürünler2;

    @Test
    @Deprecated

    public void BeymenTestApp() throws InterruptedException {


        anaSayfa = new AnaSayfa(driver);
        anaSayfa.homePageMethod();

        aramaKutusu = new AramaKutusu(driver);
        aramaKutusu.searchBoxMethod();

        ürünler = new Ürünler(driver);
        ürünler.productsPage();

        //ürünler2 = new Ürünler2(driver);
        //ürünler2.productsPage2();

        ürünDetayı = new ÜrünDetayı(driver);
        ürünDetayı.productDetails();

        sepetim = new Sepetim(driver);
        sepetim.basketPageMethod();

        ürünSilme = new ÜrünSilme(driver);
        ürünSilme.deletionPage();

    }
}